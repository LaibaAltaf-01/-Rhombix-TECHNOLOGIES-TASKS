import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Import all screens
import HomeScreen from '../Home';
import ProfileScreen from '../ProfileScreen';
import SettingsScreen from '../SettingsScreen';
import ContactScreen from '../ContantScreen';

// Create Stack Navigator
const Stack = createNativeStackNavigator();


// Main Navigation Root
export default function RootNavigator() {
  return (
    <NavigationContainer>

      <Stack.Navigator
        screenOptions={{
          
          // Header background color
          headerStyle: {
            backgroundColor: '#007AFF',
          },

          // Header text and back button color
          headerTintColor: '#fff',

          // Header title style
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: 18,
          },

          // Screen background
          contentStyle: {
            backgroundColor: '#f5f5f5',
          },
        }}
      >

        {/* HOME SCREEN */}
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: 'Home Screen',
          }}
        />

        {/* PROFILE SCREEN */}
        <Stack.Screen
          name="Profile"
          component={ProfileScreen}
          options={{
            title: 'Profile',
          }}
        />

        {/* SETTINGS SCREEN */}
        <Stack.Screen
          name="Settings"
          component={SettingsScreen}
          options={{
            title: 'Settings',
          }}
        />

        {/* CONTACT SCREEN */}
        <Stack.Screen
          name="Contact"
          component={ContactScreen}
          options={{
            title: 'Contact',
          }}
        />

      </Stack.Navigator>

    </NavigationContainer>
  );
}