import React, { useState } from 'react';
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { createStyles } from './StyleSheet';

const profileImage = {
  uri: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80',
};

export default function ProfileScreen({ goToScreen, theme }) {
  const styles = createStyles(theme);
  const [name, setName] = useState('');
  const [age, setAge] = useState('');

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.card}>
          <Image source={profileImage} style={styles.profileImage} />
          <Text style={styles.title}>Your profile</Text>
          <Text style={styles.subtitle}>Tell us a little about the person behind the smile.</Text>

          <TextInput
            style={styles.input}
            placeholder="Your name"
            placeholderTextColor={theme.muted}
            value={name}
            onChangeText={setName}
          />
          <TextInput
            style={styles.input}
            placeholder="Your age"
            placeholderTextColor={theme.muted}
            value={age}
            onChangeText={setAge}
            keyboardType="numeric"
            inputMode="numeric"
          />

          <Text style={styles.liveLabel}>Live preview</Text>
          <Text style={styles.liveValue}>Name: {name || 'Your name will appear here'}</Text>
          <Text style={styles.liveValue}>Age: {age || 'Your age will appear here'}</Text>
        </View>

        <TouchableOpacity style={styles.button} onPress={() => goToScreen('home')}>
          <Text style={styles.buttonText}>Back to home</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
