import React, { useState } from 'react';
import {
  Alert,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { createStyles } from './StyleSheet';

const contactBackground = {
  uri: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80',
};

export default function ContactScreen({ goToScreen, theme }) {
  const styles = createStyles(theme);
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const submitMessage = () => {
    if (!message.trim()) {
      Alert.alert('Add a message', 'Please write a message before sending.');
      return;
    }

    Alert.alert('Message sent', `Thanks! We will reply to ${email || 'your email soon'}.`);
    setEmail('');
    setMessage('');
  };

  return (
    <ImageBackground
      source={contactBackground}
      style={styles.container}
      imageStyle={{ opacity: 0.2 }}
      resizeMode="cover"
    >
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>Stay in touch</Text>
        <Text style={styles.title}>Contact us</Text>
        <Text style={styles.subtitle}>
          Send a note whenever you need a hand or simply want to say hello.
        </Text>

        <View style={styles.card}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Ionicons name="mail-outline" size={24} color={theme.primaryDark} />
            <TextInput
              style={[styles.input, { flex: 1, marginLeft: 10 }]}
              placeholder="Your email address"
              placeholderTextColor={theme.muted}
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
            />
          </View>
          <TextInput
            style={[styles.input, { height: 120, textAlignVertical: 'top', paddingTop: 14 }]}
            placeholder="Write your message..."
            placeholderTextColor={theme.muted}
            multiline
            value={message}
            onChangeText={setMessage}
          />
        </View>

        <TouchableOpacity style={styles.button} onPress={submitMessage}>
          <Text style={styles.buttonText}>Send message</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, styles.secondaryButton]}
          onPress={() => goToScreen('home')}
        >
          <Text style={[styles.buttonText, styles.secondaryButtonText]}>Back to home</Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
}
