import React from 'react';
import {
  ImageBackground,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { createStyles } from './StyleSheet';

const backgroundImage = {
  uri: 'https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=1200&q=80',
};

export default function HomeScreen({ goToScreen, theme }) {
  const styles = createStyles(theme);

  return (
    <ImageBackground
      source={backgroundImage}
      style={styles.container}
      imageStyle={styles.homeBackgroundImage}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.container}>
        <View style={styles.homeContent}>
          <View style={styles.homeIconRow} accessibilityLabel="Welcome decorations">
            <Ionicons name="sparkles-outline" size={22} color={theme.primaryDark} />
            <Ionicons name="heart-outline" size={19} color={theme.primaryDark} />
            <Ionicons name="sunny-outline" size={23} color={theme.primaryDark} />
          </View>
          <Text style={styles.eyebrow}>A little space for you</Text>
          <Text style={styles.heroTitle}>Welcome to your bright little world.</Text>
          <Text style={styles.heroSubtitle}>
            Keep your profile close, adjust your mood, and stay connected with ease.
          </Text>

          <TouchableOpacity style={styles.button} onPress={() => goToScreen('profile')}>
            <Ionicons name="person-circle-outline" size={21} color="#FFFFFF" />
            <Text style={styles.buttonText}>Open my profile</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.secondaryButton]}
            onPress={() => goToScreen('settings')}
          >
            <Ionicons name="options-outline" size={21} color={theme.text} />
            <Text style={[styles.buttonText, styles.secondaryButtonText]}>Tune my settings</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, styles.secondaryButton]}
            onPress={() => goToScreen('contact')}
          >
            <Ionicons name="chatbubble-ellipses-outline" size={21} color={theme.text} />
            <Text style={[styles.buttonText, styles.secondaryButtonText]}>Say hello</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
}
