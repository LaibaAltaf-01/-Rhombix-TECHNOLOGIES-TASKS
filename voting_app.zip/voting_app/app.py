import os
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_db, init_db, log_activity

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-in-production")

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "info"


# ---------------------------------------------------------------------------
# User model / loader
# ---------------------------------------------------------------------------
class User(UserMixin):
    def __init__(self, row):
        self.id = row["id"]
        self.username = row["username"]
        self.email = row["email"]
        self.is_admin = bool(row["is_admin"])


@login_manager.user_loader
def load_user(user_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return User(row) if row else None


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return wrapper


def now_iso():
    return datetime.now(timezone.utc).replace(tzinfo=None).isoformat()


def parse_dt(value):
    """Parse an ISO datetime string from a form input, or return None."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def poll_status(poll):
    """Return 'upcoming', 'open', or 'closed' based on start/end times."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    start = datetime.fromisoformat(poll["start_time"]) if poll["start_time"] else None
    end = datetime.fromisoformat(poll["end_time"]) if poll["end_time"] else None
    if start and now < start:
        return "upcoming"
    if end and now > end:
        return "closed"
    return "open"


def results_visible_to_voter(poll):
    status = poll_status(poll)
    vis = poll["results_visibility"]
    if vis == "admin_only":
        return False
    if vis == "live":
        return True
    if vis == "after_close":
        return status == "closed"
    return False


app.jinja_env.globals.update(poll_status=poll_status, results_visible_to_voter=results_visible_to_voter)


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not username or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("register.html")
        if len(password) < 8:
            flash("Password must be at least 8 characters long.", "danger")
            return render_template("register.html")
        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        conn = get_db()
        existing = conn.execute(
            "SELECT id FROM users WHERE username = ? OR email = ?", (username, email)
        ).fetchone()
        if existing:
            conn.close()
            flash("Username or email already registered.", "danger")
            return render_template("register.html")

        # First registered user becomes admin automatically
        user_count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
        is_admin = 1 if user_count == 0 else 0

        conn.execute(
            "INSERT INTO users (username, email, password_hash, is_admin, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, email, generate_password_hash(password), is_admin, now_iso()),
        )
        conn.commit()
        new_id = conn.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()["id"]
        conn.close()

        log_activity(new_id, "register", f"New account created ({'admin' if is_admin else 'voter'})")
        flash("Account created successfully. Please sign in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        identifier = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db()
        row = conn.execute(
            "SELECT * FROM users WHERE username = ? OR email = ?", (identifier, identifier.lower())
        ).fetchone()

        if row and check_password_hash(row["password_hash"], password):
            conn.execute("UPDATE users SET last_login = ? WHERE id = ?", (now_iso(), row["id"]))
            conn.commit()
            conn.close()
            login_user(User(row))
            log_activity(row["id"], "login", "User signed in")
            flash(f"Welcome back, {row['username']}!", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("dashboard"))

        conn.close()
        flash("Invalid username/email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    log_activity(current_user.id, "logout", "User signed out")
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Voter routes
# ---------------------------------------------------------------------------
@app.route("/")
@login_required
def dashboard():
    conn = get_db()
    polls = conn.execute("SELECT * FROM polls ORDER BY created_at DESC").fetchall()

    voted_poll_ids = {
        row["poll_id"]
        for row in conn.execute(
            "SELECT poll_id FROM votes WHERE user_id = ?", (current_user.id,)
        ).fetchall()
    }
    conn.close()

    return render_template("dashboard.html", polls=polls, voted_poll_ids=voted_poll_ids)


@app.route("/poll/<int:poll_id>", methods=["GET", "POST"])
@login_required
def poll_detail(poll_id):
    conn = get_db()
    poll = conn.execute("SELECT * FROM polls WHERE id = ?", (poll_id,)).fetchone()
    if not poll:
        conn.close()
        abort(404)

    options = conn.execute("SELECT * FROM options WHERE poll_id = ?", (poll_id,)).fetchall()
    existing_vote = conn.execute(
        "SELECT * FROM votes WHERE poll_id = ? AND user_id = ?", (poll_id, current_user.id)
    ).fetchone()

    status = poll_status(poll)

    if request.method == "POST":
        if existing_vote:
            flash("You have already voted in this poll.", "warning")
            conn.close()
            return redirect(url_for("poll_detail", poll_id=poll_id))
        if status != "open":
            flash("This poll is not currently open for voting.", "warning")
            conn.close()
            return redirect(url_for("poll_detail", poll_id=poll_id))

        option_id = request.form.get("option_id")
        valid_option = conn.execute(
            "SELECT id FROM options WHERE id = ? AND poll_id = ?", (option_id, poll_id)
        ).fetchone()
        if not valid_option:
            flash("Invalid option selected.", "danger")
            conn.close()
            return redirect(url_for("poll_detail", poll_id=poll_id))

        try:
            conn.execute(
                "INSERT INTO votes (poll_id, option_id, user_id, voted_at) VALUES (?, ?, ?, ?)",
                (poll_id, option_id, current_user.id, now_iso()),
            )
            conn.commit()
            log_activity(current_user.id, "vote", f"Voted in poll #{poll_id}")
            flash("Your vote has been recorded. Thank you!", "success")
        except Exception:
            flash("You have already voted in this poll.", "warning")

        conn.close()
        return redirect(url_for("poll_detail", poll_id=poll_id))

    results = None
    if current_user.is_admin or results_visible_to_voter(poll):
        results = conn.execute(
            """
            SELECT o.id, o.option_text, COUNT(v.id) AS vote_count
            FROM options o
            LEFT JOIN votes v ON v.option_id = o.id
            WHERE o.poll_id = ?
            GROUP BY o.id
            ORDER BY o.id
            """,
            (poll_id,),
        ).fetchall()

    conn.close()
    show_results = bool(results is not None)

    return render_template(
        "poll_detail.html",
        poll=poll,
        options=options,
        existing_vote=existing_vote,
        status=status,
        results=results,
        show_results=show_results,
    )


@app.route("/poll/<int:poll_id>/results.json")
@login_required
def poll_results_json(poll_id):
    """Lightweight endpoint polled by JS for near-real-time vote counts."""
    conn = get_db()
    poll = conn.execute("SELECT * FROM polls WHERE id = ?", (poll_id,)).fetchone()
    if not poll:
        conn.close()
        return jsonify({"error": "not found"}), 404

    allowed = current_user.is_admin or results_visible_to_voter(poll)
    if not allowed:
        conn.close()
        return jsonify({"error": "results not visible yet"}), 403

    rows = conn.execute(
        """
        SELECT o.id, o.option_text, COUNT(v.id) AS vote_count
        FROM options o
        LEFT JOIN votes v ON v.option_id = o.id
        WHERE o.poll_id = ?
        GROUP BY o.id
        ORDER BY o.id
        """,
        (poll_id,),
    ).fetchall()
    conn.close()

    total = sum(r["vote_count"] for r in rows)
    return jsonify({
        "total_votes": total,
        "options": [
            {"id": r["id"], "text": r["option_text"], "votes": r["vote_count"]}
            for r in rows
        ],
    })


# ---------------------------------------------------------------------------
# Admin routes
# ---------------------------------------------------------------------------
@app.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    conn = get_db()
    polls = conn.execute("SELECT * FROM polls ORDER BY created_at DESC").fetchall()
    user_count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    vote_count = conn.execute("SELECT COUNT(*) AS c FROM votes").fetchone()["c"]
    recent_activity = conn.execute(
        """
        SELECT a.*, u.username
        FROM activity_log a
        LEFT JOIN users u ON u.id = a.user_id
        ORDER BY a.timestamp DESC
        LIMIT 25
        """
    ).fetchall()
    conn.close()
    return render_template(
        "admin/admin_dashboard.html",
        polls=polls,
        user_count=user_count,
        vote_count=vote_count,
        recent_activity=recent_activity,
    )


@app.route("/admin/polls/new", methods=["GET", "POST"])
@login_required
@admin_required
def create_poll():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        start_time = request.form.get("start_time") or None
        end_time = request.form.get("end_time") or None
        visibility = request.form.get("results_visibility", "after_close")
        option_texts = [o.strip() for o in request.form.getlist("options") if o.strip()]

        if not title or len(option_texts) < 2:
            flash("A poll needs a title and at least two options.", "danger")
            return render_template("admin/create_poll.html")

        conn = get_db()
        conn.execute(
            """INSERT INTO polls
               (title, description, created_by, start_time, end_time, results_visibility, is_active, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 1, ?)""",
            (title, description, current_user.id, start_time, end_time, visibility, now_iso()),
        )
        poll_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        for opt in option_texts:
            conn.execute(
                "INSERT INTO options (poll_id, option_text) VALUES (?, ?)", (poll_id, opt)
            )
        conn.commit()
        conn.close()

        log_activity(current_user.id, "create_poll", f"Created poll '{title}' (#{poll_id})")
        flash("Poll created successfully.", "success")
        return redirect(url_for("admin_dashboard"))

    return render_template("admin/create_poll.html")


@app.route("/admin/polls/<int:poll_id>")
@login_required
@admin_required
def manage_poll(poll_id):
    conn = get_db()
    poll = conn.execute("SELECT * FROM polls WHERE id = ?", (poll_id,)).fetchone()
    if not poll:
        conn.close()
        abort(404)

    results = conn.execute(
        """
        SELECT o.id, o.option_text, COUNT(v.id) AS vote_count
        FROM options o
        LEFT JOIN votes v ON v.option_id = o.id
        WHERE o.poll_id = ?
        GROUP BY o.id
        ORDER BY o.id
        """,
        (poll_id,),
    ).fetchall()

    voters = conn.execute(
        """
        SELECT u.username, v.voted_at
        FROM votes v
        JOIN users u ON u.id = v.user_id
        WHERE v.poll_id = ?
        ORDER BY v.voted_at DESC
        """,
        (poll_id,),
    ).fetchall()
    conn.close()

    return render_template(
        "admin/manage_poll.html", poll=poll, results=results, voters=voters, status=poll_status(poll)
    )


@app.route("/admin/polls/<int:poll_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_poll(poll_id):
    conn = get_db()
    poll = conn.execute("SELECT * FROM polls WHERE id = ?", (poll_id,)).fetchone()
    if not poll:
        conn.close()
        abort(404)
    new_state = 0 if poll["is_active"] else 1
    conn.execute("UPDATE polls SET is_active = ? WHERE id = ?", (new_state, poll_id))
    conn.commit()
    conn.close()
    log_activity(current_user.id, "toggle_poll", f"Poll #{poll_id} set active={new_state}")
    flash("Poll status updated.", "info")
    return redirect(url_for("manage_poll", poll_id=poll_id))


@app.route("/admin/polls/<int:poll_id>/visibility", methods=["POST"])
@login_required
@admin_required
def set_visibility(poll_id):
    visibility = request.form.get("results_visibility", "after_close")
    if visibility not in ("live", "after_close", "admin_only"):
        abort(400)
    conn = get_db()
    conn.execute("UPDATE polls SET results_visibility = ? WHERE id = ?", (visibility, poll_id))
    conn.commit()
    conn.close()
    log_activity(current_user.id, "set_visibility", f"Poll #{poll_id} visibility -> {visibility}")
    flash("Result visibility updated.", "info")
    return redirect(url_for("manage_poll", poll_id=poll_id))


@app.route("/admin/polls/<int:poll_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_poll(poll_id):
    conn = get_db()
    conn.execute("DELETE FROM polls WHERE id = ?", (poll_id,))
    conn.commit()
    conn.close()
    log_activity(current_user.id, "delete_poll", f"Deleted poll #{poll_id}")
    flash("Poll deleted.", "info")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users")
@login_required
@admin_required
def manage_users():
    conn = get_db()
    users = conn.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template("admin/users.html", users=users)


@app.errorhandler(403)
def forbidden(e):
    return render_template("error.html", code=403, message="You don't have permission to view this page."), 403


@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", code=404, message="Page not found."), 404


if __name__ == "__main__":
    init_db()
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(debug=debug_mode, host="0.0.0.0", port=5000)
