# SecureVote — Online Voting Application

A secure, full-stack online voting app built with **Flask** (Python).

## Features
- **Authentication**: Register/login with hashed passwords (scrypt via Werkzeug), sessions via Flask-Login.
- **One vote per poll**: Enforced at the database level with a `UNIQUE(poll_id, user_id)` constraint plus application checks, so it holds even under concurrent/replayed requests.
- **Admin panel**:
  - Create polls with 2–4 options, optional start/end times, and a results-visibility mode.
  - View live vote counts, per-poll voter activity (who voted, when), and a site-wide activity log.
  - Activate/deactivate or delete polls.
  - View all registered users and their roles.
- **Poll timing**: Polls can have a start time (upcoming) and end time (closed); voting is only allowed while a poll is "open" — checked server-side on every submission, not just the UI.
- **Result visibility control** (per poll):
  - `live` — voters see results immediately
  - `after_close` — voters see results only once the poll closes
  - `admin_only` — results are never shown to voters, only admins
- **Real-time-ish vote counts**: The poll page polls a lightweight JSON endpoint (`/poll/<id>/results.json`) every 4 seconds and animates the result bars — no page refresh needed.

## Project structure
```
voting_app/
├── app.py               # Flask app: routes, auth, admin logic
├── database.py          # SQLite schema + init + activity logging
├── templates/            # Jinja2 HTML templates
│   ├── base.html, login.html, register.html
│   ├── dashboard.html, poll_detail.html, error.html
│   └── admin/            # admin_dashboard, create_poll, manage_poll, users
└── static/style.css      # Styling
```

## Running it
```bash
pip install flask flask-login --break-system-packages
python3 app.py
```
Visit **http://localhost:5000**. The **first account you register automatically becomes the admin**; every account after that is a regular voter.

For production, set a real `SECRET_KEY` environment variable, set `FLASK_DEBUG=1` only for local development, and run behind a proper WSGI server (gunicorn/uwsgi) instead of the built-in dev server.

## Security model
- Passwords are never stored in plaintext — only scrypt hashes (via `werkzeug.security`).
- Votes are tied to `user_id` with a unique DB constraint, so a user cannot vote twice in the same poll.
- All poll-modifying admin routes are protected by an `@admin_required` decorator (403 for non-admins).
- Poll status (upcoming/open/closed) is computed server-side from `start_time`/`end_time`.

## Testing performed
Verified end-to-end via HTTP requests: registration, login, admin-only route protection (403 for voters), poll creation, vote casting, duplicate-vote blocking, poll timing (upcoming/closed polls reject votes), all three result-visibility modes, live results JSON updates, and password hashing (no plaintext in the DB).
