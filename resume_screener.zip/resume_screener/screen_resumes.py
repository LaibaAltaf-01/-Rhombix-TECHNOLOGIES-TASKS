#!/usr/bin/env python3
"""
screen_resumes.py — Automated Resume Screener CLI

Scans a folder of resumes (.pdf / .docx), scores each against a job
requirements config (skills, keywords, experience, education), and
produces a ranked report of shortlisted candidates.

Usage:
    python screen_resumes.py --resumes ./resumes --config job.json

    python screen_resumes.py --resumes ./resumes --config job.json \\
        --output report.xlsx --csv report.csv

    python screen_resumes.py --resumes ./resumes --config job.json \\
        --email-to hr@company.com

Run `python screen_resumes.py --help` for all options.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from extractors import ExtractionError, extract_text, iter_resume_files
from matcher import JobRequirements, score_candidate
from report import print_console_summary, write_csv, write_excel


def load_requirements(config_path: Path) -> JobRequirements:
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.exit(f"Config file not found: {config_path}")
    except json.JSONDecodeError as e:
        sys.exit(f"Config file '{config_path}' is not valid JSON: {e}")

    try:
        return JobRequirements.from_dict(data)
    except (TypeError, ValueError) as e:
        sys.exit(f"Invalid job requirements config: {e}")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Automated Resume Screener — scan PDF/DOCX resumes and shortlist candidates.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--resumes", "-r", required=True, type=Path,
        help="Directory containing resume files (.pdf and/or .docx).",
    )
    parser.add_argument(
        "--config", "-c", required=True, type=Path,
        help="Path to a JSON file describing the job requirements. "
             "See config_example.json for the format.",
    )
    parser.add_argument(
        "--output", "-o", type=Path, default=None,
        help="Path to write an Excel (.xlsx) report. Default: <resumes-dir>/screening_report.xlsx",
    )
    parser.add_argument(
        "--csv", type=Path, default=None,
        help="Optional: also write a CSV report to this path.",
    )
    parser.add_argument(
        "--no-excel", action="store_true",
        help="Skip writing the Excel report (useful if you only want CSV/console output).",
    )
    parser.add_argument(
        "--email-to", type=str, default=None,
        help="Optional: email address to send a shortlist alert to. Requires SMTP_HOST, "
             "SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD environment variables to be set.",
    )
    parser.add_argument(
        "--quiet", "-q", action="store_true",
        help="Suppress the console summary table (still writes report files).",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)

    requirements = load_requirements(args.config)

    if not args.resumes.is_dir():
        sys.exit(f"Resume directory not found: {args.resumes}")

    resume_files = list(iter_resume_files(args.resumes))
    if not resume_files:
        sys.exit(
            f"No .pdf or .docx resumes found in {args.resumes}. "
            "Nothing to screen."
        )

    results = []
    for file_path in resume_files:
        try:
            text = extract_text(file_path)
        except ExtractionError as e:
            print(f"[skipped] {file_path.name}: {e}", file=sys.stderr)
            continue
        results.append(score_candidate(file_path.name, text, requirements))

    if not results:
        sys.exit("No resumes could be read successfully. See errors above.")

    if not args.quiet:
        print_console_summary(results, requirements)

    output_path = args.output
    if not args.no_excel:
        output_path = output_path or (args.resumes / "screening_report.xlsx")
        write_excel(results, output_path, requirements)
        print(f"Excel report written to: {output_path}")

    if args.csv:
        write_csv(results, args.csv)
        print(f"CSV report written to: {args.csv}")

    if args.email_to:
        from emailer import EmailConfigError, send_shortlist_alert
        try:
            attachment = output_path if (output_path and not args.no_excel) else args.csv
            send_shortlist_alert(args.email_to, results, requirements, attachment_path=attachment)
            print(f"Email alert sent to: {args.email_to}")
        except EmailConfigError as e:
            print(f"[email not sent] {e}", file=sys.stderr)
        except Exception as e:
            print(f"[email not sent] Failed to send email: {e}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
