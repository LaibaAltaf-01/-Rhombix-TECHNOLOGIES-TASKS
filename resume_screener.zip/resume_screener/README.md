# Automated Resume Screener

A command-line tool that scans a folder of resumes (PDF and/or DOCX),
scores each candidate against a job's requirements, and produces a
ranked, shortlisted report — as an Excel workbook, CSV, and/or console
summary. Optional email alerts notify a recruiter automatically.

## Features
- **Reads PDF and DOCX resumes** — extracts text (including from tables,
  which many resume templates use for layout).
- **Configurable job requirements** (JSON): required skills, preferred
  skills, free-text keywords, minimum years of experience, minimum
  education level.
- **Heuristic parsing**: pulls out candidate name, email, phone, estimated
  years of experience, and highest education level from raw resume text —
  no ML model, no external API calls, fully offline and auditable.
- **Weighted scoring (0–100)** across required skills, preferred skills,
  keywords, experience, and education — weights are configurable per job.
- **Shortlisting**: candidates at/above a configurable score threshold are
  flagged automatically.
- **Reports**:
  - Formatted Excel workbook (`.xlsx`) with "All Candidates," "Shortlisted,"
    and "Job Requirements" sheets, shortlisted rows highlighted.
  - CSV export.
  - Console summary table.
- **Optional email alerts**: send the shortlist (with the report attached)
  to a recruiter via SMTP.
- **Graceful error handling**: unreadable/corrupted files are skipped with
  a warning instead of crashing the run.

## Installation
```bash
pip install -r requirements.txt
```

## Quick start
1. Put resumes (`.pdf` / `.docx`) in a folder, e.g. `./resumes/`.
2. Copy `config_example.json` and edit it for your job — see below.
3. Run:
   ```bash
   python screen_resumes.py --resumes ./resumes --config job.json
   ```
   This prints a ranked summary to the console and writes
   `./resumes/screening_report.xlsx`.

### Try it immediately with sample data
Sample resumes are already included in `sample_resumes/` (or regenerate
them with `python generate_sample_resumes.py`):
```bash
python screen_resumes.py --resumes sample_resumes --config config_example.json
```

## Job requirements config format
```json
{
  "job_title": "Backend Software Engineer",
  "required_skills": ["python", "sql", "git", "rest api"],
  "preferred_skills": ["docker", "aws", "kubernetes", "ci/cd"],
  "keywords": ["agile", "team lead", "microservices"],
  "min_experience_years": 3,
  "min_education": "bachelor",
  "shortlist_threshold": 60,
  "weights": {
    "required_skills": 40,
    "preferred_skills": 15,
    "keywords": 10,
    "experience": 20,
    "education": 15
  }
}
```
- `min_education` must be one of: `high school`, `associate`, `bachelor`,
  `master`, `phd`.
- `weights` don't need to sum to 100 — they're normalized automatically.
- Any field you omit falls back to a sensible default (see `matcher.py`,
  `JobRequirements`).

## Command-line options
| Flag | Description |
|---|---|
| `--resumes / -r` | Directory of resume files (required) |
| `--config / -c` | Path to the job requirements JSON (required) |
| `--output / -o` | Excel report path (default: `<resumes-dir>/screening_report.xlsx`) |
| `--csv` | Also write a CSV report to this path |
| `--no-excel` | Skip the Excel report |
| `--email-to` | Send a shortlist alert to this address (see below) |
| `--quiet / -q` | Suppress the console summary table |

## Email alerts (optional)
Set these environment variables, then pass `--email-to`:
```bash
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USERNAME=you@example.com
export SMTP_PASSWORD='your-app-password'   # use an app password, not your real password

python screen_resumes.py --resumes ./resumes --config job.json --email-to hr@company.com
```
If the environment variables aren't set, the tool prints a clear warning
and continues — it never crashes the screening run over a missing email
config, and credentials are never written to disk or logged.

## How scoring works
Each resume is scored 0–100 as a weighted combination of:
- **Required skills** — % of required skills found in the resume text
- **Preferred skills** — % of preferred/nice-to-have skills found
- **Keywords** — % of free-text keywords found (e.g. "agile", "team lead")
- **Experience** — capped ratio of estimated years vs. the minimum required
  (estimated first from an explicit "X years of experience" phrase if
  present, otherwise from the earliest–latest year span found in the
  resume's work history)
- **Education** — full credit if the highest detected degree meets the
  minimum, otherwise zero

A candidate is shortlisted if their score is at or above
`shortlist_threshold`.

## Accuracy notes & limitations
This is a fast, transparent, regex-based screener — not an ML/NLP model.
It works well on reasonably well-formatted resumes but has known limits:
- **Scanned/image-only PDFs** have no extractable text layer; those
  resumes are flagged with a warning and score based on whatever text (if
  any) could be pulled out. OCR is not built in.
- **Experience estimation** is a heuristic (explicit phrase, or date-range
  span) and can overestimate if there are large unexplained employment
  gaps, or underestimate if a resume never states dates clearly. Always
  sanity-check shortlisted candidates' experience manually before a final
  decision.
- **Name detection** is best-effort (first plausible short line at the top
  of the resume); it falls back to the filename if nothing looks like a
  name.
- Skill/keyword matching is phrase-based (case-insensitive, whole-word),
  so keep your `required_skills`/`keywords` lists reasonably specific
  (e.g. `"rest api"` rather than just `"api"`) to avoid false positives.

## Project structure
```
resume_screener/
├── screen_resumes.py          # CLI entry point
├── extractors.py               # PDF/DOCX text extraction
├── matcher.py                   # Parsing + scoring logic
├── report.py                     # Console/CSV/Excel report generation
├── emailer.py                     # Optional SMTP email alerts
├── config_example.json            # Example job requirements config
├── generate_sample_resumes.py     # Creates the sample_resumes/ demo files
├── sample_resumes/                # Ready-to-try sample resumes
└── requirements.txt
```
