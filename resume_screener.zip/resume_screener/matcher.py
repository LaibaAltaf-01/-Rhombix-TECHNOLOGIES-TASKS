"""
matcher.py — Parses resume text for candidate info and scores it against
a set of job requirements (required/preferred skills, keywords, minimum
experience, minimum education).

The parsing here is intentionally heuristic (regex-based, no ML/NLP model)
so the tool has zero heavyweight dependencies and stays predictable and
auditable — every score can be traced back to a specific matched phrase.
It won't be perfect on every resume format; see README for tips on
improving accuracy for your candidate pool.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date

# --- Education level ladder -------------------------------------------------

EDUCATION_LEVELS = {
    "high school": 1,
    "associate": 2,
    "bachelor": 3,
    "master": 4,
    "phd": 5,
}

# Regex patterns mapped to the education level they indicate. Ordered most-
# specific first isn't required since we take the MAX level found.
_EDUCATION_PATTERNS = [
    (r"\bph\.?d\.?\b|\bdoctor(ate)?\s+of\b|\bdoctoral\b", "phd"),
    (r"\bm\.?b\.?a\.?\b|\bm\.?s\.?c?\.?\b|\bm\.?a\.?\b(?!\w)|\bmaster'?s?\b", "master"),
    (r"\bb\.?s\.?c?\.?\b|\bb\.?a\.?\b(?!\w)|\bb\.?tech\.?\b|\bbachelor'?s?\b", "bachelor"),
    (r"\bassociate'?s?\s+degree\b|\ba\.?a\.?s?\.?\b(?=\s+degree)", "associate"),
    (r"\bhigh\s*school\s+diploma\b|\bg\.?e\.?d\.?\b", "high school"),
]

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(
    r"(?:\+?\d{1,3}[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b"
)
_EXPLICIT_YEARS_RE = re.compile(
    r"(\d{1,2}(?:\.\d)?)\+?\s*(?:years?|yrs?)\s*(?:of\s+)?(?:professional\s+|relevant\s+|work(?:ing)?\s+)?experience",
    re.IGNORECASE,
)
_YEAR_RANGE_RE = re.compile(
    r"\b(19|20)\d{2}\b\s*(?:-|–|—|to)\s*(\b(?:19|20)\d{2}\b|present|current|now)",
    re.IGNORECASE,
)
_YEAR_ONLY_RE = re.compile(r"\b(19|20)\d{2}\b")


@dataclass
class JobRequirements:
    job_title: str = "Untitled Position"
    required_skills: list[str] = field(default_factory=list)
    preferred_skills: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)
    min_experience_years: float = 0
    min_education: str | None = None  # one of EDUCATION_LEVELS keys, or None
    shortlist_threshold: float = 60.0
    weights: dict = field(
        default_factory=lambda: {
            "required_skills": 40,
            "preferred_skills": 15,
            "keywords": 10,
            "experience": 20,
            "education": 15,
        }
    )

    @classmethod
    def from_dict(cls, data: dict) -> "JobRequirements":
        known = {f for f in cls.__dataclass_fields__}
        filtered = {k: v for k, v in data.items() if k in known}
        req = cls(**filtered)
        if req.min_education:
            req.min_education = req.min_education.strip().lower()
            if req.min_education not in EDUCATION_LEVELS:
                raise ValueError(
                    f"Unknown min_education '{req.min_education}'. "
                    f"Valid options: {', '.join(EDUCATION_LEVELS)}"
                )
        return req


@dataclass
class CandidateResult:
    file_name: str
    candidate_name: str
    email: str | None
    phone: str | None
    matched_required_skills: list[str]
    missing_required_skills: list[str]
    matched_preferred_skills: list[str]
    matched_keywords: list[str]
    estimated_experience_years: float
    highest_education: str | None
    score: float
    shortlisted: bool
    notes: list[str] = field(default_factory=list)


def _find_phrase(text_lower: str, phrase: str) -> bool:
    """Whole-word(ish) substring match, tolerant of punctuation/spacing."""
    pattern = r"(?<![a-z0-9])" + re.escape(phrase.lower()) + r"(?![a-z0-9])"
    return re.search(pattern, text_lower) is not None


def extract_email(text: str) -> str | None:
    match = _EMAIL_RE.search(text)
    return match.group(0) if match else None


def extract_phone(text: str) -> str | None:
    match = _PHONE_RE.search(text)
    return match.group(0) if match else None


def guess_candidate_name(text: str, fallback: str) -> str:
    """
    Best-effort name guess: the first non-empty line that doesn't look like
    an email, phone number, URL, or section heading. Falls back to the
    filename (without extension) if nothing plausible is found.
    """
    for raw_line in text.splitlines()[:8]:
        line = raw_line.strip()
        if not line or len(line) > 60:
            continue
        if _EMAIL_RE.search(line) or _PHONE_RE.search(line):
            continue
        if any(ch.isdigit() for ch in line):
            continue
        if line.lower() in {"resume", "curriculum vitae", "cv"}:
            continue
        # Looks like a name: 2-4 words, mostly alphabetic
        words = line.split()
        if 1 < len(words) <= 4 and all(w.replace("-", "").replace(".", "").isalpha() for w in words):
            return line
    return fallback


def estimate_experience_years(text: str) -> float:
    """
    Heuristic total-experience estimate, in order of trust:
    1. An explicit "X years of experience" phrase, if present (most reliable).
    2. Otherwise, derive a span from the earliest to the most recent year
       mentioned in a YYYY-YYYY / YYYY-Present style range. This is a rough
       approximation (assumes no long unexplained gaps) and reviewers should
       still confirm on top candidates.
    """
    explicit_matches = _EXPLICIT_YEARS_RE.findall(text)
    if explicit_matches:
        return max(float(m) for m in explicit_matches)

    years_seen = []
    for match in _YEAR_RANGE_RE.finditer(text):
        start_year = int(match.group(0)[:4])
        end_raw = match.group(2).lower()
        end_year = date.today().year if end_raw in ("present", "current", "now") else int(end_raw)
        if 1950 <= start_year <= date.today().year and start_year <= end_year <= date.today().year + 1:
            years_seen.append(start_year)
            years_seen.append(end_year)

    if years_seen:
        return float(max(years_seen) - min(years_seen))

    # Last resort: any 4-digit years at all, take the span.
    lone_years = [int(y) for y in _YEAR_ONLY_RE.findall(text)]
    plausible = [y for y in lone_years if 1970 <= y <= date.today().year]
    if len(plausible) >= 2:
        return float(max(plausible) - min(plausible))

    return 0.0


def detect_highest_education(text: str) -> str | None:
    text_lower = text.lower()
    found_levels = []
    for pattern, level in _EDUCATION_PATTERNS:
        if re.search(pattern, text_lower):
            found_levels.append(EDUCATION_LEVELS[level])
    if not found_levels:
        return None
    highest = max(found_levels)
    for name, value in EDUCATION_LEVELS.items():
        if value == highest:
            return name
    return None


def match_skills(text: str, skills: list[str]) -> tuple[list[str], list[str]]:
    """Returns (matched, missing) preserving the input order/casing."""
    text_lower = text.lower()
    matched, missing = [], []
    for skill in skills:
        if _find_phrase(text_lower, skill):
            matched.append(skill)
        else:
            missing.append(skill)
    return matched, missing


def score_candidate(
    file_name: str,
    text: str,
    requirements: JobRequirements,
) -> CandidateResult:
    notes = []

    if not text.strip():
        notes.append("No extractable text — file may be a scanned image or corrupted.")

    matched_required, missing_required = match_skills(text, requirements.required_skills)
    matched_preferred, _ = match_skills(text, requirements.preferred_skills)
    matched_keywords, _ = match_skills(text, requirements.keywords)

    experience_years = estimate_experience_years(text)
    education = detect_highest_education(text)

    weights = requirements.weights
    total_weight = sum(weights.values()) or 1

    # Required skills
    req_score = 0.0
    if requirements.required_skills:
        req_score = (len(matched_required) / len(requirements.required_skills)) * weights.get("required_skills", 0)
    elif "required_skills" in weights:
        req_score = weights["required_skills"]  # no requirement set = free points

    # Preferred skills
    pref_score = 0.0
    if requirements.preferred_skills:
        pref_score = (len(matched_preferred) / len(requirements.preferred_skills)) * weights.get("preferred_skills", 0)
    elif "preferred_skills" in weights:
        pref_score = weights["preferred_skills"]

    # Keywords
    kw_score = 0.0
    if requirements.keywords:
        kw_score = (len(matched_keywords) / len(requirements.keywords)) * weights.get("keywords", 0)
    elif "keywords" in weights:
        kw_score = weights["keywords"]

    # Experience
    exp_weight = weights.get("experience", 0)
    if requirements.min_experience_years > 0:
        exp_score = min(1.0, experience_years / requirements.min_experience_years) * exp_weight
    else:
        exp_score = exp_weight  # no minimum set = free points

    # Education
    edu_weight = weights.get("education", 0)
    if requirements.min_education:
        candidate_level = EDUCATION_LEVELS.get(education, 0)
        required_level = EDUCATION_LEVELS[requirements.min_education]
        edu_score = edu_weight if candidate_level >= required_level else 0.0
        if candidate_level == 0:
            notes.append("No recognizable education credential found in resume text.")
    else:
        edu_score = edu_weight

    raw_score = req_score + pref_score + kw_score + exp_score + edu_score
    final_score = round((raw_score / total_weight) * 100, 1)

    shortlisted = final_score >= requirements.shortlist_threshold
    if requirements.required_skills and missing_required:
        notes.append(f"Missing required skill(s): {', '.join(missing_required)}")

    name = guess_candidate_name(text, fallback=file_name.rsplit(".", 1)[0])

    return CandidateResult(
        file_name=file_name,
        candidate_name=name,
        email=extract_email(text),
        phone=extract_phone(text),
        matched_required_skills=matched_required,
        missing_required_skills=missing_required,
        matched_preferred_skills=matched_preferred,
        matched_keywords=matched_keywords,
        estimated_experience_years=experience_years,
        highest_education=education,
        score=final_score,
        shortlisted=shortlisted,
        notes=notes,
    )
