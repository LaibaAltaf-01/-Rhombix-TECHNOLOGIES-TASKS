"""
generate_sample_resumes.py — Creates a handful of fake resumes (mixed
PDF/DOCX, varying strength) so the screener can be test-run end to end.
Not part of the shipped tool — just a convenience for trying it out.
"""

from pathlib import Path

from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

OUT_DIR = Path(__file__).parent / "sample_resumes"
OUT_DIR.mkdir(exist_ok=True)


def make_docx(filename: str, lines: list[str]):
    doc = Document()
    for line in lines:
        doc.add_paragraph(line)
    doc.save(OUT_DIR / filename)


def make_pdf(filename: str, lines: list[str]):
    path = OUT_DIR / filename
    c = canvas.Canvas(str(path), pagesize=letter)
    width, height = letter
    y = height - 60
    for line in lines:
        if y < 60:
            c.showPage()
            y = height - 60
        c.drawString(50, y, line)
        y -= 16
    c.save()


# --- Candidate 1: strong match (DOCX) ---------------------------------------
make_docx("jordan_lee.docx", [
    "Jordan Lee",
    "jordan.lee@example.com | (555) 234-8871",
    "",
    "SUMMARY",
    "Backend engineer with 6 years of experience building scalable REST APIs "
    "and distributed systems.",
    "",
    "SKILLS",
    "Python, SQL, Git, REST API design, Docker, AWS, Kubernetes, CI/CD, microservices",
    "",
    "EXPERIENCE",
    "Senior Software Engineer — Northwind Systems, 2019 - Present",
    "Led a team of 4 engineers migrating a monolith to microservices on AWS. "
    "Owned CI/CD pipeline and Kubernetes deployment.",
    "",
    "Software Engineer — Initech, 2017 - 2019",
    "Built REST APIs in Python/Flask backed by PostgreSQL (SQL).",
    "",
    "EDUCATION",
    "Bachelor of Science in Computer Science, State University, 2017",
])

# --- Candidate 2: moderate match (PDF) --------------------------------------
make_pdf("morgan_reyes.pdf", [
    "Morgan Reyes",
    "morgan.reyes@example.com",
    "",
    "SUMMARY",
    "Software developer with 2 years of experience in Python and SQL.",
    "",
    "SKILLS",
    "Python, SQL, Git, HTML, CSS, Agile",
    "",
    "EXPERIENCE",
    "Junior Developer - Foobar Inc, 2022 - Present",
    "Maintained internal tools, wrote SQL queries, participated in agile team lead standups.",
    "",
    "EDUCATION",
    "Associate's Degree in Information Technology, Community College, 2021",
])

# --- Candidate 3: weak match (DOCX) -----------------------------------------
make_docx("casey_owens.docx", [
    "Casey Owens",
    "casey.owens@example.com | 555-901-2244",
    "",
    "SUMMARY",
    "Recent graduate interested in a career in graphic design.",
    "",
    "SKILLS",
    "Adobe Photoshop, Illustrator, InDesign, branding, typography",
    "",
    "EXPERIENCE",
    "Design Intern - Creative Studio, 2023 - Present",
    "",
    "EDUCATION",
    "High School Diploma, Lincoln High School, 2020",
])

# --- Candidate 4: strong match (PDF), unusual formatting --------------------
make_pdf("alex_kim.pdf", [
    "ALEX KIM",
    "Senior Backend Engineer",
    "alex.kim99@example.com  |  +1 (555) 777-3210",
    "",
    "8+ years of experience in backend development.",
    "",
    "Technical Skills: Python, SQL, Git, REST API, Docker, AWS, CI/CD",
    "",
    "Work History",
    "Principal Engineer, Globex Corp, 2016 - Present",
    "Architected microservices platform; mentored engineers; drove agile adoption.",
    "",
    "Education: Master of Science in Computer Science, Tech Institute, 2015",
])

print("Sample resumes generated in:", OUT_DIR)
for p in sorted(OUT_DIR.iterdir()):
    print(" -", p.name)
