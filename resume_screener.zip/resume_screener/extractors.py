"""
extractors.py — Pulls raw text out of resume files (.pdf and .docx).

Two extraction backends are used deliberately:
- pdfplumber for PDFs (handles multi-column layouts better than a bare
  text-layer dump, and degrades gracefully on odd PDFs)
- python-docx for Word documents (reads paragraphs AND table cells, since
  a lot of resume templates put content in tables)
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger("resume_screener.extractors")

SUPPORTED_EXTENSIONS = {".pdf", ".docx"}


class ExtractionError(Exception):
    """Raised when a resume file can't be read at all."""


def extract_text(file_path: Path) -> str:
    """Dispatch to the right extractor based on file extension."""
    suffix = file_path.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(file_path)
    if suffix == ".docx":
        return _extract_docx(file_path)
    raise ExtractionError(
        f"Unsupported file type '{suffix}' for {file_path.name}. "
        f"Supported types: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
    )


def _extract_pdf(file_path: Path) -> str:
    try:
        import pdfplumber
    except ImportError as e:
        raise ExtractionError(
            "pdfplumber is required to read PDF resumes. Install it with "
            "`pip install pdfplumber`."
        ) from e

    text_parts = []
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text_parts.append(page_text)
    except Exception as e:  # pdfplumber can raise a variety of parser errors
        raise ExtractionError(f"Could not parse PDF '{file_path.name}': {e}") from e

    text = "\n".join(text_parts).strip()
    if not text:
        # Likely a scanned/image-only PDF with no text layer.
        logger.warning(
            "No extractable text found in %s — it may be a scanned/image-only "
            "PDF. OCR is not performed by this tool.",
            file_path.name,
        )
    return text


def _extract_docx(file_path: Path) -> str:
    try:
        import docx
    except ImportError as e:
        raise ExtractionError(
            "python-docx is required to read DOCX resumes. Install it with "
            "`pip install python-docx`."
        ) from e

    try:
        document = docx.Document(str(file_path))
    except Exception as e:
        raise ExtractionError(f"Could not parse DOCX '{file_path.name}': {e}") from e

    chunks = []

    for para in document.paragraphs:
        if para.text.strip():
            chunks.append(para.text)

    # Many resume templates place content (skills lists, experience tables)
    # inside tables, which document.paragraphs skips entirely.
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    chunks.append(cell.text)

    return "\n".join(chunks).strip()


def iter_resume_files(directory: Path):
    """Yield every supported resume file in a directory (non-recursive)."""
    if not directory.is_dir():
        raise NotADirectoryError(f"'{directory}' is not a directory.")
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS:
            yield path
