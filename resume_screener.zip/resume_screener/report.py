"""
report.py — Turns a list of CandidateResult objects into human-usable
output: a console summary table, a CSV file, and/or a formatted Excel
workbook (shortlisted candidates on their own sheet for quick review).
"""

from __future__ import annotations

import csv
from pathlib import Path

from matcher import CandidateResult

COLUMNS = [
    ("candidate_name", "Candidate"),
    ("file_name", "File"),
    ("score", "Score"),
    ("shortlisted", "Shortlisted"),
    ("estimated_experience_years", "Experience (yrs)"),
    ("highest_education", "Education"),
    ("email", "Email"),
    ("phone", "Phone"),
    ("matched_required_skills", "Matched Required Skills"),
    ("missing_required_skills", "Missing Required Skills"),
    ("matched_preferred_skills", "Matched Preferred Skills"),
    ("matched_keywords", "Matched Keywords"),
    ("notes", "Notes"),
]


def _row_value(result: CandidateResult, attr: str):
    value = getattr(result, attr)
    if isinstance(value, list):
        return ", ".join(value) if value else "—"
    if value is None:
        return "—"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return value


def print_console_summary(results: list[CandidateResult], requirements) -> None:
    ranked = sorted(results, key=lambda r: r.score, reverse=True)
    shortlisted = [r for r in ranked if r.shortlisted]

    print()
    print(f"Job: {requirements.job_title}")
    print(f"Screened {len(results)} resume(s)  |  Shortlisted {len(shortlisted)} "
          f"(threshold: {requirements.shortlist_threshold})")
    print("-" * 78)
    header = f"{'#':<3} {'Candidate':<24} {'Score':>6}  {'Shortlisted':<11} {'Exp (yrs)':>9}  Education"
    print(header)
    print("-" * 78)
    for i, r in enumerate(ranked, start=1):
        print(
            f"{i:<3} {r.candidate_name[:24]:<24} {r.score:>6.1f}  "
            f"{'YES' if r.shortlisted else 'no':<11} {r.estimated_experience_years:>9.1f}  "
            f"{r.highest_education or '—'}"
        )
    print("-" * 78)
    if shortlisted:
        print("Shortlisted: " + ", ".join(r.candidate_name for r in shortlisted))
    else:
        print("No candidates met the shortlist threshold.")
    print()


def write_csv(results: list[CandidateResult], output_path: Path) -> None:
    ranked = sorted(results, key=lambda r: r.score, reverse=True)
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(label for _, label in COLUMNS)
        for r in ranked:
            writer.writerow(_row_value(r, attr) for attr, _ in COLUMNS)


def write_excel(results: list[CandidateResult], output_path: Path, requirements) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    ranked = sorted(results, key=lambda r: r.score, reverse=True)
    shortlisted = [r for r in ranked if r.shortlisted]

    wb = Workbook()

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4F46E5", end_color="4F46E5", fill_type="solid")
    shortlist_fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
    wrap = Alignment(wrap_text=True, vertical="top")

    def write_sheet(ws, rows: list[CandidateResult]):
        for col_idx, (_, label) in enumerate(COLUMNS, start=1):
            cell = ws.cell(row=1, column=col_idx, value=label)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(vertical="center")
        for row_idx, r in enumerate(rows, start=2):
            for col_idx, (attr, _) in enumerate(COLUMNS, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=_row_value(r, attr))
                cell.alignment = wrap
                if r.shortlisted:
                    cell.fill = shortlist_fill
        # Reasonable column widths
        widths = [22, 22, 8, 12, 14, 12, 26, 16, 30, 30, 26, 24, 34]
        for col_idx, width in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(col_idx)].width = width
        ws.freeze_panes = "A2"

    ws_summary = wb.active
    ws_summary.title = "All Candidates"
    write_sheet(ws_summary, ranked)

    ws_short = wb.create_sheet("Shortlisted")
    write_sheet(ws_short, shortlisted)

    ws_meta = wb.create_sheet("Job Requirements")
    ws_meta.append(["Field", "Value"])
    for cell in ws_meta[1]:
        cell.font = header_font
        cell.fill = header_fill
    meta_rows = [
        ("Job Title", requirements.job_title),
        ("Required Skills", ", ".join(requirements.required_skills) or "—"),
        ("Preferred Skills", ", ".join(requirements.preferred_skills) or "—"),
        ("Keywords", ", ".join(requirements.keywords) or "—"),
        ("Minimum Experience (years)", requirements.min_experience_years),
        ("Minimum Education", requirements.min_education or "—"),
        ("Shortlist Threshold (score)", requirements.shortlist_threshold),
        ("Total Resumes Screened", len(results)),
        ("Total Shortlisted", len(shortlisted)),
    ]
    for row in meta_rows:
        ws_meta.append(row)
    ws_meta.column_dimensions["A"].width = 28
    ws_meta.column_dimensions["B"].width = 50

    wb.save(output_path)
