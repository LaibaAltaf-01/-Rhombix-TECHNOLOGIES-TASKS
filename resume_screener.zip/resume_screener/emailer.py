"""
emailer.py — Optional email alert: sends a summary of shortlisted
candidates (with the Excel/CSV report attached) via SMTP.

This is entirely opt-in. It's only used if the user passes --email-to
on the command line AND has SMTP credentials available via environment
variables. Nothing about the core screening/reporting flow depends on it.

Required environment variables (never hardcode credentials in the script):
    SMTP_HOST       e.g. smtp.gmail.com
    SMTP_PORT       e.g. 587
    SMTP_USERNAME   the account to send from
    SMTP_PASSWORD   an app password / SMTP password (NOT stored anywhere)
"""

from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from pathlib import Path

from matcher import CandidateResult


class EmailConfigError(Exception):
    pass


def send_shortlist_alert(
    to_address: str,
    results: list[CandidateResult],
    requirements,
    attachment_path: Path | None = None,
) -> None:
    host = os.environ.get("SMTP_HOST")
    port = os.environ.get("SMTP_PORT")
    username = os.environ.get("SMTP_USERNAME")
    password = os.environ.get("SMTP_PASSWORD")

    missing = [
        name for name, val in
        [("SMTP_HOST", host), ("SMTP_PORT", port), ("SMTP_USERNAME", username), ("SMTP_PASSWORD", password)]
        if not val
    ]
    if missing:
        raise EmailConfigError(
            "Cannot send email alert — missing environment variable(s): "
            f"{', '.join(missing)}. Set these before using --email-to, e.g.:\n"
            "  export SMTP_HOST=smtp.gmail.com\n"
            "  export SMTP_PORT=587\n"
            "  export SMTP_USERNAME=you@example.com\n"
            "  export SMTP_PASSWORD='your-app-password'"
        )

    shortlisted = sorted(
        (r for r in results if r.shortlisted), key=lambda r: r.score, reverse=True
    )

    msg = EmailMessage()
    msg["Subject"] = f"Resume Screening Results: {requirements.job_title} " \
                      f"({len(shortlisted)} shortlisted)"
    msg["From"] = username
    msg["To"] = to_address

    lines = [
        f"Automated resume screening complete for: {requirements.job_title}",
        "",
        f"Resumes screened: {len(results)}",
        f"Shortlisted:      {len(shortlisted)} (threshold: {requirements.shortlist_threshold})",
        "",
    ]
    if shortlisted:
        lines.append("Shortlisted candidates:")
        for r in shortlisted:
            lines.append(
                f"  - {r.candidate_name}  |  score {r.score}  |  "
                f"{r.estimated_experience_years:.1f} yrs  |  {r.email or 'no email found'}"
            )
    else:
        lines.append("No candidates met the shortlist threshold this run.")

    if attachment_path:
        lines.append("")
        lines.append(f"Full report attached: {attachment_path.name}")

    msg.set_content("\n".join(lines))

    if attachment_path and attachment_path.exists():
        data = attachment_path.read_bytes()
        maintype, subtype = ("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet") \
            if attachment_path.suffix == ".xlsx" else ("text", "csv")
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=attachment_path.name)

    with smtplib.SMTP(host, int(port)) as server:
        server.starttls()
        server.login(username, password)
        server.send_message(msg)
